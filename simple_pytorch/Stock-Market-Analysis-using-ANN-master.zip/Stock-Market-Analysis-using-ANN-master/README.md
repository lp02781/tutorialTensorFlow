# Stock-Market-Analysis-using-ANN

Stock analysis is the evaluation of a particular trading instrument, an investment sector, or the market as a whole. Stock analysts attempt to determine the future activity of an instrument, sector, or market

In this project I have tried to predict future stock prices of Edelweiss Broking Limited using simple Artificial Neural Network regression model
